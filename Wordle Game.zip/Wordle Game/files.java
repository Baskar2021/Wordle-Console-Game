import java.io.File;
import java.util.*;
import java.io.FileNotFoundException;

class files{

	public static String getWord()
	{
		int count=0;
		Random random = new Random();
		int randomNumber=random.nextInt(5756);
		File fp = new File("World.txt");
		String data="nails";
		try{
			Scanner input = new Scanner(fp);
			while(input.hasNextLine())
			{
				data = input.nextLine();
				count++;
				if(count==randomNumber)
					break;
			}
			input.close();
			return data;
		}
		catch(Exception e){
			System.out.println(e);
			return data;
		}
	}

	public static boolean isMeaningfull(String word){
		File fp = new File("World.txt");
		String data="f";
		try{
			Scanner input = new Scanner(fp);
			while(input.hasNextLine())
			{
				data = input.nextLine();
				if(word.equals(data))
					return true;
			}
			input.close();
			return false;
		}
		catch(Exception e){
			System.out.println(e);
			return false;
		}
	}
	
	public static String endWord(int n){
		if(n==1 || n==5)
			return "th";
		return "nd";
	}

	public static int startGame(String word){
		int alphabet1[] = new int[27];
		int alphabet2[] = new int[27];
		int chances=1;
		String str="p";
		int index;
		char letter;
		Scanner input = new Scanner(System.in);
		
		while(chances<=6){
			System.out.print("Chance : " + chances + ", Enter the word : ");
			str=input.nextLine();
			str=str.toLowerCase();
				
			if(files.isMeaningfull(str)==true)
			{
				for(int i=1; i<27; i++)
					alphabet1[i]=alphabet2[i]=0;
				if(str.equals(word))
				{
					System.out.println("Congratulations");
					return 0;
				}	
				else
				{
					for(int i=0; i<5; i++)
					{
						if(str.charAt(i)!=word.charAt(i)){
							index=word.charAt(i);
							alphabet1[index-96]=alphabet1[index-96]+1;
							index=str.charAt(i);
							alphabet2[index-96]=alphabet2[index-96]+1;
						}
						else{
							System.out.println(str.charAt(i) + " matches at " + (i+1) + files.endWord(i+1) +" position");
						}
					}
					for(int i=1; i<=26; i++)
					{
						if(alphabet1[i]!=0 && alphabet2[i]!=0)
						{
							if(alphabet1[i]<=alphabet2[i])
							{
								index=96+i;
								letter=(char)index;
								System.out.println( letter + " matches at random " + alphabet1[i] + " position");
							}
						}
					}
				}
			}
			else
			{
				System.out.println("Enter the meaning full word");
				chances--;		
			}
			chances++;
		}
		System.out.println("Sorry, try for next word");
		return 0;
	}
	

	public static void main(String [] args){
		files.startGame(files.getWord());
	}
}
